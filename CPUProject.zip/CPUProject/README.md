# CPUProject
C based CPU project based on the ARM Architecture

load function
Loads a file into memory

dump function
dumps loaded memory provided that an offset is given and the
number of bytes you want to read 

Trace function
Executes the Fetch instruction and displays the registries

Fetch function 
Reads one instruction at a time
